import type { TurboModule } from 'react-native';
export interface Spec extends TurboModule {
    updateTags(tags: {
        [key: string]: string;
    }): void;
}
declare const _default: Spec;
export default _default;
//# sourceMappingURL=NativeTrackingplanReactNative.d.ts.map