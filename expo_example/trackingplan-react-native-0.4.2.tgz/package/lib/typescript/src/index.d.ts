/**
 * Trackingplan SDK for React Native
 */
declare class Trackingplan {
    /**
     * Updates the tags in the current Trackingplan configuration.
     * This method can be called after the SDK has been initialized via the Expo plugin
     * or manual native configuration.
     *
     * @param tags - An object containing key-value pairs of tags to update
     * @example
     * // Update locale when user changes language
     * Trackingplan.updateTags({
     *   site_locale: 'es-ES',
     *   country: 'ES'
     * });
     */
    static updateTags(tags: Record<string, string>): void;
}
export default Trackingplan;
//# sourceMappingURL=index.d.ts.map